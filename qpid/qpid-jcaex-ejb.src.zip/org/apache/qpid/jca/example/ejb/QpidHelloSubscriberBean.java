/*    */ package org.apache.qpid.jca.example.ejb;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.annotation.Resource;
/*    */ import javax.ejb.MessageDriven;
/*    */ import javax.jms.Connection;
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.jms.Destination;
/*    */ import javax.jms.Message;
/*    */ import javax.jms.MessageListener;
/*    */ import javax.jms.MessageProducer;
/*    */ import javax.jms.Session;
/*    */ import javax.jms.TextMessage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @MessageDriven(activationConfig={@javax.ejb.ActivationConfigProperty(propertyName="acknowledgeMode", propertyValue="Auto-acknowledge"), @javax.ejb.ActivationConfigProperty(propertyName="destinationType", propertyValue="javax.jms.Topic"), @javax.ejb.ActivationConfigProperty(propertyName="destination", propertyValue="java:jboss/exported/HelloTopic"), @javax.ejb.ActivationConfigProperty(propertyName="connectionURL", propertyValue="amqp://anonymous:passwd@client/test?brokerlist='tcp://localhost?sasl_mechs='PLAIN''"), @javax.ejb.ActivationConfigProperty(propertyName="subscriptionDurability", propertyValue="NotDurable"), @javax.ejb.ActivationConfigProperty(propertyName="maxSession", propertyValue="10")})
/*    */ public class QpidHelloSubscriberBean
/*    */   implements MessageListener
/*    */ {
/* 52 */   private static final Logger _log = LoggerFactory.getLogger(QpidHelloSubscriberBean.class);
/*    */ 
/*    */   @Resource(name="java:/QpidJMSXA")
/*    */   private ConnectionFactory _connectionFactory;
/*    */ 
/*    */   @Resource(name="java:jboss/exported/GoodByeTopic")
/*    */   private Destination _topic;
/*    */ 
/*    */   public void onMessage(Message message) {
/* 63 */     Connection connection = null;
/* 64 */     Session session = null;
/* 65 */     MessageProducer messageProducer = null;
/* 66 */     TextMessage response = null;
/*    */     try
/*    */     {
/* 70 */       if ((message instanceof TextMessage))
/*    */       {
/* 72 */         String content = ((TextMessage)message).getText();
/*    */ 
/* 74 */         _log.info("Received text message with contents: [" + content + "] at " + new Date());
/*    */ 
/* 76 */         StringBuffer temp = new StringBuffer();
/* 77 */         temp.append("QpidHelloSubscriberBean received message with content: [" + content);
/* 78 */         temp.append("] at " + new Date());
/*    */ 
/* 80 */         if ((message.propertyExists("say.goodbye")) && (message.getBooleanProperty("say.goodbye")))
/*    */         {
/* 82 */           connection = this._connectionFactory.createConnection();
/* 83 */           session = connection.createSession(false, 1);
/* 84 */           messageProducer = session.createProducer(this._topic);
/* 85 */           response = session.createTextMessage(temp.toString());
/* 86 */           messageProducer.send(response);
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 92 */       _log.error(e.getMessage(), e);
/*    */     }
/*    */     finally
/*    */     {
/* 96 */       QpidUtil.closeResources(new Object[] { session, connection });
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\jboss\jboss-as-7.1.1.Final\standalone\qpid-jcaex-ejb.jar
 * Qualified Name:     org.apache.qpid.jca.example.ejb.QpidHelloSubscriberBean
 * JD-Core Version:    0.6.1
 */