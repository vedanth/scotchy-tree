package org.apache.qpid.jca.example.ejb;

public abstract interface QpidTest
{
  public abstract void testQpidAdapter(String paramString)
    throws Exception;

  public abstract void testQpidAdapter(String paramString, int paramInt)
    throws Exception;

  public abstract void testQpidAdapter(String paramString, int paramInt, boolean paramBoolean)
    throws Exception;

  public abstract void testQpidAdapter(String paramString, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
    throws Exception;
}

/* Location:           F:\jboss\jboss-as-7.1.1.Final\standalone\qpid-jcaex-ejb.jar
 * Qualified Name:     org.apache.qpid.jca.example.ejb.QpidTest
 * JD-Core Version:    0.6.1
 */