/*    */ package org.apache.qpid.jca.example.ejb;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.ejb.MessageDriven;
/*    */ import javax.jms.Message;
/*    */ import javax.jms.MessageListener;
/*    */ import javax.jms.TextMessage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @MessageDriven(activationConfig={@javax.ejb.ActivationConfigProperty(propertyName="acknowledgeMode", propertyValue="Auto-acknowledge"), @javax.ejb.ActivationConfigProperty(propertyName="destinationType", propertyValue="javax.jms.Queue"), @javax.ejb.ActivationConfigProperty(propertyName="destination", propertyValue="java:jboss/exported/GoodByeQueue"), @javax.ejb.ActivationConfigProperty(propertyName="connectionURL", propertyValue="amqp://anonymous:passwd@client/test?brokerlist='tcp://localhost?sasl_mechs='PLAIN''"), @javax.ejb.ActivationConfigProperty(propertyName="useLocalTx", propertyValue="false"), @javax.ejb.ActivationConfigProperty(propertyName="maxSession", propertyValue="10")})
/*    */ public class QpidGoodByeListenerBean
/*    */   implements MessageListener
/*    */ {
/* 44 */   private static final Logger _log = LoggerFactory.getLogger(QpidGoodByeListenerBean.class);
/*    */ 
/*    */   public void onMessage(Message message)
/*    */   {
/*    */     try
/*    */     {
/* 51 */       if ((message instanceof TextMessage))
/*    */       {
/* 53 */         String content = ((TextMessage)message).getText();
/*    */ 
/* 55 */         _log.info("Received text message with contents: [" + content + "] at " + new Date());
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 60 */       _log.error(e.getMessage(), e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\jboss\jboss-as-7.1.1.Final\standalone\qpid-jcaex-ejb.jar
 * Qualified Name:     org.apache.qpid.jca.example.ejb.QpidGoodByeListenerBean
 * JD-Core Version:    0.6.1
 */