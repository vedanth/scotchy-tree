/*    */ package org.apache.qpid.jca.example.ejb;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.annotation.Resource;
/*    */ import javax.ejb.MessageDriven;
/*    */ import javax.jms.Connection;
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.jms.Message;
/*    */ import javax.jms.MessageListener;
/*    */ import javax.jms.MessageProducer;
/*    */ import javax.jms.Session;
/*    */ import javax.jms.TextMessage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @MessageDriven(activationConfig={@javax.ejb.ActivationConfigProperty(propertyName="acknowledgeMode", propertyValue="Auto-acknowledge"), @javax.ejb.ActivationConfigProperty(propertyName="destinationType", propertyValue="javax.jms.Queue"), @javax.ejb.ActivationConfigProperty(propertyName="destination", propertyValue="java:jboss/exported/QpidRequestQueue"), @javax.ejb.ActivationConfigProperty(propertyName="connectionURL", propertyValue="amqp://anonymous:passwd@client/test?brokerlist='tcp://localhost?sasl_mechs='PLAIN''"), @javax.ejb.ActivationConfigProperty(propertyName="maxSession", propertyValue="10")})
/*    */ public class QpidJMSResponderBean
/*    */   implements MessageListener
/*    */ {
/* 51 */   private static final Logger _log = LoggerFactory.getLogger(QpidJMSResponderBean.class);
/*    */ 
/*    */   @Resource(name="java:/QpidJMSXA")
/*    */   private ConnectionFactory _connectionFactory;
/*    */ 
/*    */   public void onMessage(Message message)
/*    */   {
/* 59 */     Connection connection = null;
/* 60 */     Session session = null;
/* 61 */     MessageProducer messageProducer = null;
/* 62 */     TextMessage response = null;
/*    */     try
/*    */     {
/* 66 */       if ((message instanceof TextMessage))
/*    */       {
/* 68 */         String content = ((TextMessage)message).getText();
/*    */ 
/* 70 */         _log.info("Received text message with contents: [" + content + "] at " + new Date());
/*    */ 
/* 72 */         StringBuffer temp = new StringBuffer();
/* 73 */         temp.append("QpidJMSResponderBean received message with content: [" + content);
/* 74 */         temp.append("] at " + new Date());
/*    */ 
/* 76 */         connection = this._connectionFactory.createConnection();
/* 77 */         session = connection.createSession(false, 1);
/*    */ 
/* 79 */         if (message.getJMSReplyTo() != null)
/*    */         {
/* 81 */           _log.info("Sending response via JMSReplyTo");
/* 82 */           messageProducer = session.createProducer(message.getJMSReplyTo());
/* 83 */           response = session.createTextMessage();
/* 84 */           response.setText(temp.toString());
/* 85 */           messageProducer.send(response);
/*    */         }
/*    */         else
/*    */         {
/* 89 */           _log.info("JMSReplyTo is null. Will not respond to message.");
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 97 */       _log.error(e.getMessage(), e);
/*    */     }
/*    */     finally
/*    */     {
/* 101 */       QpidUtil.closeResources(new Object[] { session, connection });
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\jboss\jboss-as-7.1.1.Final\standalone\qpid-jcaex-ejb.jar
 * Qualified Name:     org.apache.qpid.jca.example.ejb.QpidJMSResponderBean
 * JD-Core Version:    0.6.1
 */