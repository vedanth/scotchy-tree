/*    */ package org.apache.qpid.jca.example.ejb;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Enumeration;
/*    */ import javax.jms.Message;
/*    */ import javax.jms.TextMessage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class QpidUtil
/*    */ {
/* 34 */   private static final Logger _log = LoggerFactory.getLogger(QpidTestBean.class);
/*    */ 
/*    */   public static void handleMessage(String beanName, Message message) throws Exception
/*    */   {
/* 38 */     if ((message instanceof TextMessage))
/*    */     {
/* 40 */       String content = ((TextMessage)message).getText();
/* 41 */       _log.debug(beanName + ": Received text message with contents " + content);
/*    */ 
/* 43 */       if (content.contains("PrintEnv"))
/*    */       {
/* 45 */         printJMSHeaders(message);
/* 46 */         printProperties(message);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void printProperties(Message message)
/*    */     throws Exception
/*    */   {
/* 54 */     _log.debug("Priting Message Properties:");
/*    */ 
/* 56 */     Enumeration e = message.getPropertyNames();
/*    */ 
/* 58 */     while (e.hasMoreElements())
/*    */     {
/* 60 */       _log.debug(e + ":" + message.getObjectProperty(e.toString()));
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void printJMSHeaders(Message message) throws Exception
/*    */   {
/* 66 */     _log.debug("JMSCorrelationID:" + message.getJMSCorrelationID());
/* 67 */     _log.debug("JMSDeliveryMode:" + message.getJMSDeliveryMode());
/* 68 */     _log.debug("JMSExpires:" + message.getJMSExpiration());
/* 69 */     _log.debug("JMSMessageID:" + message.getJMSMessageID());
/* 70 */     _log.debug("JMSPriority:" + message.getJMSPriority());
/* 71 */     _log.debug("JMSTimestamp:" + message.getJMSTimestamp());
/* 72 */     _log.debug("JMSType:" + message.getJMSType());
/* 73 */     _log.debug("JMSReplyTo:" + message.getJMSReplyTo());
/*    */   }
/*    */ 
/*    */   public static void closeResources(Object[] objects)
/*    */   {
/*    */     try
/*    */     {
/* 80 */       for (Object object : objects)
/*    */       {
/* 82 */         Method close = object.getClass().getMethod("close", new Class[0]);
/* 83 */         close.invoke(object, new Object[0]);
/*    */       }
/*    */     }
/*    */     catch (Exception ignore)
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\jboss\jboss-as-7.1.1.Final\standalone\qpid-jcaex-ejb.jar
 * Qualified Name:     org.apache.qpid.jca.example.ejb.QpidUtil
 * JD-Core Version:    0.6.1
 */