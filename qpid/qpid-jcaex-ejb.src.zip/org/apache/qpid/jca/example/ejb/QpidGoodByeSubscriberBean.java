/*    */ package org.apache.qpid.jca.example.ejb;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.ejb.MessageDriven;
/*    */ import javax.jms.Message;
/*    */ import javax.jms.MessageListener;
/*    */ import javax.jms.TextMessage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @MessageDriven(activationConfig={@javax.ejb.ActivationConfigProperty(propertyName="acknowledgeMode", propertyValue="Auto-acknowledge"), @javax.ejb.ActivationConfigProperty(propertyName="destinationType", propertyValue="javax.jms.Topic"), @javax.ejb.ActivationConfigProperty(propertyName="destination", propertyValue="java:jboss/exported/GoodByeTopic"), @javax.ejb.ActivationConfigProperty(propertyName="connectionURL", propertyValue="amqp://anonymous:passwd@client/test?brokerlist='tcp://localhost?sasl_mechs='PLAIN''"), @javax.ejb.ActivationConfigProperty(propertyName="subscriptionDurability", propertyValue="NotDurable"), @javax.ejb.ActivationConfigProperty(propertyName="maxSession", propertyValue="10")})
/*    */ public class QpidGoodByeSubscriberBean
/*    */   implements MessageListener
/*    */ {
/* 45 */   private static final Logger _log = LoggerFactory.getLogger(QpidGoodByeSubscriberBean.class);
/*    */ 
/*    */   public void onMessage(Message message)
/*    */   {
/*    */     try
/*    */     {
/* 52 */       if ((message instanceof TextMessage))
/*    */       {
/* 54 */         String content = ((TextMessage)message).getText();
/*    */ 
/* 56 */         _log.info("Received text message with contents: [" + content + "] at " + new Date());
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 61 */       _log.error(e.getMessage(), e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\jboss\jboss-as-7.1.1.Final\standalone\qpid-jcaex-ejb.jar
 * Qualified Name:     org.apache.qpid.jca.example.ejb.QpidGoodByeSubscriberBean
 * JD-Core Version:    0.6.1
 */