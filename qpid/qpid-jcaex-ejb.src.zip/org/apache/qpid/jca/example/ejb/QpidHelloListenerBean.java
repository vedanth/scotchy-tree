/*    */ package org.apache.qpid.jca.example.ejb;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.annotation.Resource;
/*    */ import javax.ejb.MessageDriven;
/*    */ import javax.jms.Connection;
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.jms.Destination;
/*    */ import javax.jms.Message;
/*    */ import javax.jms.MessageListener;
/*    */ import javax.jms.MessageProducer;
/*    */ import javax.jms.Session;
/*    */ import javax.jms.TextMessage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @MessageDriven(activationConfig={@javax.ejb.ActivationConfigProperty(propertyName="acknowledgeMode", propertyValue="Auto-acknowledge"), @javax.ejb.ActivationConfigProperty(propertyName="destinationType", propertyValue="javax.jms.Queue"), @javax.ejb.ActivationConfigProperty(propertyName="destination", propertyValue="java:jboss/exported/HelloQueue"), @javax.ejb.ActivationConfigProperty(propertyName="connectionURL", propertyValue="amqp://anonymous:passwd@client/test?brokerlist='tcp://localhost?sasl_mechs='PLAIN''"), @javax.ejb.ActivationConfigProperty(propertyName="maxSession", propertyValue="10")})
/*    */ public class QpidHelloListenerBean
/*    */   implements MessageListener
/*    */ {
/* 51 */   private static final Logger _log = LoggerFactory.getLogger(QpidHelloListenerBean.class);
/*    */ 
/*    */   @Resource(name="java:/QpidJMSXA")
/*    */   private ConnectionFactory _connectionFactory;
/*    */ 
/*    */   @Resource(name="java:jboss/exported/GoodByeQueue")
/*    */   private Destination _queue;
/*    */ 
/*    */   public void onMessage(Message message) {
/* 62 */     Connection connection = null;
/* 63 */     Session session = null;
/* 64 */     MessageProducer messageProducer = null;
/* 65 */     TextMessage response = null;
/*    */     try
/*    */     {
/* 69 */       if ((message instanceof TextMessage))
/*    */       {
/* 71 */         String content = ((TextMessage)message).getText();
/*    */ 
/* 73 */         _log.info("Received text message with contents: [" + content + "] at " + new Date());
/*    */ 
/* 75 */         StringBuffer temp = new StringBuffer();
/* 76 */         temp.append("QpidHelloListenerBean received message with content: [" + content);
/* 77 */         temp.append("] at " + new Date());
/*    */ 
/* 79 */         if ((message.propertyExists("say.goodbye")) && (message.getBooleanProperty("say.goodbye")))
/*    */         {
/* 81 */           connection = this._connectionFactory.createConnection();
/* 82 */           session = connection.createSession(false, 1);
/* 83 */           messageProducer = session.createProducer(this._queue);
/* 84 */           response = session.createTextMessage(temp.toString());
/* 85 */           messageProducer.send(response);
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 91 */       _log.error(e.getMessage(), e);
/*    */     }
/*    */     finally
/*    */     {
/* 95 */       QpidUtil.closeResources(new Object[] { session, connection });
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\jboss\jboss-as-7.1.1.Final\standalone\qpid-jcaex-ejb.jar
 * Qualified Name:     org.apache.qpid.jca.example.ejb.QpidHelloListenerBean
 * JD-Core Version:    0.6.1
 */