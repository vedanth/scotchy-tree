/*    */ package org.apache.qpid.jca.example.ejb;
/*    */ 
/*    */ import javax.annotation.Resource;
/*    */ import javax.ejb.Stateless;
/*    */ import javax.jms.Connection;
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.jms.Destination;
/*    */ import javax.jms.MessageProducer;
/*    */ import javax.jms.Session;
/*    */ import javax.jms.TextMessage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @Stateless
/*    */ public class QpidTestBean
/*    */   implements QpidTestRemote, QpidTestLocal
/*    */ {
/* 41 */   private static final Logger _log = LoggerFactory.getLogger(QpidTestBean.class);
/*    */ 
/*    */   @Resource(name="java:/QpidJMSXA")
/*    */   private ConnectionFactory _connectionFactory;
/*    */ 
/*    */   @Resource(name="java:jboss/exported/HelloQueue")
/*    */   private Destination _queue;
/*    */ 
/*    */   @Resource(name="java:jboss/exported/HelloTopic")
/*    */   private Destination _topic;
/*    */ 
/* 55 */   public void testQpidAdapter(String content) throws Exception { testQpidAdapter(content, 1); }
/*    */ 
/*    */ 
/*    */   public void testQpidAdapter(String content, int count)
/*    */     throws Exception
/*    */   {
/* 61 */     testQpidAdapter(content, count, false);
/*    */   }
/*    */ 
/*    */   public void testQpidAdapter(String content, int count, boolean useTopic) throws Exception
/*    */   {
/* 66 */     testQpidAdapter(content, count, useTopic, false, false);
/*    */   }
/*    */ 
/*    */   public void testQpidAdapter(String content, int count, boolean useTopic, boolean respond, boolean sayGoodbye)
/*    */     throws Exception
/*    */   {
/* 73 */     Connection connection = null;
/* 74 */     Session session = null;
/* 75 */     MessageProducer messageProducer = null;
/*    */ 
/* 77 */     _log.info("Sending " + count + " message(s) to MDB with content " + content);
/*    */     try
/*    */     {
/* 81 */       connection = this._connectionFactory.createConnection();
/* 82 */       session = connection.createSession(false, 1);
/* 83 */       messageProducer = useTopic ? session.createProducer(this._topic) : session.createProducer(this._queue);
/*    */ 
/* 85 */       for (int i = 0; i < count; i++)
/*    */       {
/* 87 */         TextMessage message = session.createTextMessage(content);
/* 88 */         message.setBooleanProperty("say.goodbye", sayGoodbye);
/* 89 */         messageProducer.send(message);
/*    */       }
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 95 */       _log.error(e.getMessage(), e);
/* 96 */       throw e;
/*    */     }
/*    */     finally
/*    */     {
/* 100 */       QpidUtil.closeResources(new Object[] { messageProducer, session, connection });
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\jboss\jboss-as-7.1.1.Final\standalone\qpid-jcaex-ejb.jar
 * Qualified Name:     org.apache.qpid.jca.example.ejb.QpidTestBean
 * JD-Core Version:    0.6.1
 */