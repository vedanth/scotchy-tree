package org.apache.qpid.jca.example.ejb;

import javax.ejb.Local;

@Local
public abstract interface QpidTestLocal extends QpidTest
{
}

/* Location:           F:\jboss\jboss-as-7.1.1.Final\standalone\qpid-jcaex-ejb.jar
 * Qualified Name:     org.apache.qpid.jca.example.ejb.QpidTestLocal
 * JD-Core Version:    0.6.1
 */